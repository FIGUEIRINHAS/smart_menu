<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'welcome';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['pages'] = 'pages/view';
$route['(:any)'] = 'pages/view/$1';

/**
 * ROUTES USERS 
 */
$route['users/subscribe'] = 'users_controller/subscribe_form';
$route['users/login'] = 'users_controller/login_form';
$route['users/create'] = 'users_controller/create';
$route['users/connect'] = 'users_controller/connect';

/**
 * ROUTES MANAGER
 */
$route['manager/establishment'] = 'establishments_controller/display_form';
$route['establishment/create'] = 'establishments_controller/create_establishment';
$route['manager/dashboard'] = 'users_controller/get_dashboard';
$route['manager/products'] = 'products_controller/get_all_products';
$route['product/create'] = 'products_controller/create_product';
$route['manager/categories'] = 'categories_controller/get_all_categories';
$route['category/create'] = 'categories_controller/create_category';
$route['manager/category/(:num)'] = 'categories_controller/get_one_category/$1';
$route['product/category/(:num)'] = 'products_controller/set_category_id_for_product/$1';
$route['manager/menus'] = 'menus_controller/get_all_menus';
$route['menu/form'] = 'menus_controller/menu_form';
$route['menu/create'] = 'menus_controller/create_menu';
$route['manager/menu/(:num)'] = 'menus_controller/get_one_menu/$1';
$route['menu/delete/(:num)'] = 'menus_controller/delete_menu/$1';
$route['category/delete/(:num)'] = "categories_controller/delete_category/$1";

/**
 * ROUTES CLIENTS
 */