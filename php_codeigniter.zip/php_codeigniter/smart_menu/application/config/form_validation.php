<?php

$config = array(
    'subscribe' => array(
        array(
            'field' => 'email',
            'label' => 'E-mail',
            'rules' => 'required|valid_emails'
        ),
        array(
            'field' => 'password',
            'label' => 'Mot de passe',
            'rules' => 'required|min_length[5]|max_length[20]'
        ),
        array(
            'field' => 'password_verif',
            'label' => 'Vérification du mot de passe',
            'rules' => 'required|min_length[5]|max_length[20]'
        ),
        array(
            'field' => 'type',
            'label' => 'Type',
            'rules' => 'required'
        ),
    ),
    'connect' => array(
        array(
            'field' => 'email',
            'label' => 'E-mail',
            'rules' => 'required|valid_emails'
        ),
        array(
            'field' => 'password',
            'label' => 'Mot de passe',
            'rules' => 'required|min_length[5]|max_length[20]'
        ),
    ),
    'establishement_create' => array(
        array(
            'field' => 'address',
            'label' => 'Adresse',
            'rules' => 'required'
        ),
        array(
            'field' => 'postal_code',
            'label' => 'Code postal',
            'rules' => 'required|min_length[5]|max_length[5]'
        ),
        array(
            'field' => 'city',
            'label' => 'Ville',
            'rules' => 'required'
        ),
        array(
            'field' => 'tel',
            'label' => 'Téléphone',
            'rules' => 'required|numeric|min_length[10]|max_length[10]'
        ),
        array(
            'field' => 'website',
            'label' => 'Site-web',
            'rules' => ''
        ),
        array(
            'field' => 'menu_address',
            'label' => 'Adresse restaurant',
            'rules' => ''
        )
    ),
    'product_create' => array(
        array(
            'field' => 'name',
            'label' => 'Name',
            'rules' => 'required'
        ),
        array(
            'field' => 'description',
            'label' => 'Description',
            'rules' => 'required'
        ),
        array(
            'field' => 'price',
            'label' => 'Prix',
            'rules' => 'required|numeric'
        )
    ),
    'category_create' => array(
        array(
            'field' => 'name',
            'label' => 'Name',
            'rules' => 'required'
        ),
        array(
            'field' => 'description',
            'label' => 'Description',
            'rules' => 'required'
        )
    ),
    'product_category' => array(
        array(
            'field' => 'O',
            'label' => 'Oui',
            'rules' => 'required'
        )
    ),
    'menu_create' => array(
        array(
            'field' => 'name',
            'label' => 'Name',
            'rules' => 'required'
        ),
        array(
            'field' => 'description',
            'label' => 'Description',
            'rules' => 'required'
        ),
        array(
            'field' => 'speciality',
            'label' => 'Spécialité',
            'rules' => 'required'
        )
    ),
);