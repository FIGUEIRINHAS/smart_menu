<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Products_controller extends CI_Controller {

	public function index(){
		$this->load->view('welcome_message');
    }
    
    public function get_all_products(){
        $this->load->model('products_model');
        $data['products'] = $this->products_model->select_all_by($_SESSION['establishment_id']);

        $this->load->view('products/all_products', $data);
    }

    public function create_product(){
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');

        if($this->form_validation->run('product_create') == FALSE){
            $this->load->view('products/form_create_product');
        }else{
            $this->load->model('products_model');
            $this->products_model->set_name($_POST['name']);
            $this->products_model->set_description($_POST['description']);
            $this->products_model->set_price($_POST['price']);
            $this->products_model->set_establishment_id($_SESSION['establishment_id']);
            $this->products_model->insert();

            if($this->products_model->insert() === true){
                $data['message'] = "Vous pouvez ajouter un nouveau produit";
            }

            $this->load->view('products/form_create_product', $data);
        }
    }

    public function set_category_id_for_product($category_id){
        $this->load->model('products_model');
        $this->load->model('categories_model');

        foreach($_POST as $key => $value){
            if($value === 'on'){
                $this->products_model->add_product_category_for($key, $category_id);
                header("Location: http://localhost/php_codeigniter/smart_menu/manager/category/$category_id");
            }
        }
    }
}
