<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Menus_controller extends CI_Controller {

	public function get_all_menus(){
        $this->load->model('menus_model');
        $data['menus'] = $this->menus_model->select_all_by_establishment_id($_SESSION['establishment_id']);
        
        $this->load->view('menus/all_menus', $data);
    }

    public function menu_form(){
        $this->load->model('products_model');
        $this->load->model('categories_model');
        $data['products'] = $this->products_model->select_all_by($_SESSION['establishment_id']);
        $data['categories'] = $this->categories_model->select_all_by($_SESSION['establishment_id']);

        $this->load->view('menus/form_create_menu', $data);
    }

    public function create_menu(){
        $this->load->model('products_model');
        $this->load->model('categories_model');
        $data['products'] = $this->products_model->select_all_by($_SESSION['establishment_id']);
        $data['categories'] = $this->categories_model->select_all_by($_SESSION['establishment_id']);

        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');

        if($this->form_validation->run('menu_create') == FALSE){
            $this->load->view('menus/form_create_menu', $data);
        }else{
            $this->load->model('menus_model');
            $this->menus_model->set_name($_POST['name']);
            $this->menus_model->set_description($_POST['description']);
            $this->menus_model->set_speciality($_POST['speciality']);
            $this->menus_model->set_establishment_id($_SESSION['establishment_id']);
            $last_id = $this->menus_model->insert();

            foreach($_POST as $key => $value){
                if($value === 'on' && is_numeric($key)){
                    $this->products_model->add_product_menu_for($key, $last_id);
                    header("Location: http://localhost/php_codeigniter/smart_menu/manager/menu/$last_id");
                }
            }
            $products_menu = $this->products_model->select_by_menu($last_id);
            $price = 0;
            $new_price = 0;

            foreach($products_menu as $product){
                $price = $product['price'] + $new_price;
                $new_price = $product['price'];
            }
            $this->menus_model->add_price_menu_for($price, $last_id);
        }
    }

    public function get_one_menu($menu_id){
        $this->load->model('menus_model');
        $data['menu'] = $this->menus_model->select_by($menu_id);

        $this->load->view('menus/menu', $data);
    }

    public function delete_menu($menu_id){
        $this->load->model('menus_model');
        $this->menus_model->delete($menu_id);

        header("Location: http://localhost/php_codeigniter/smart_menu/manager/menus");        
    }
}
