<?php 

class Users_controller extends CI_Controller{

    public function subscribe_form(){
        $this->load->view('users/subscribe');
    }

    public function login_form(){
        $this->load->view('users/login');
    }

    public function create(){
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');

        if($this->form_validation->run('subscribe') == FALSE){
            $this->load->view('users/subscribe');
        }else{
            if($_POST['password'] === $_POST['password_verif']){
                $password = md5($_POST['password']);
                $email = $_POST['email'];
                $type = $_POST['type'];
                $this->load->model('users_model');
                $this->users_model->set_email($email);
                $this->users_model->set_password($password);
                $this->users_model->set_type($type);
                $this->users_model->insert();
                header('Location: http://localhost/php_codeigniter/smart_menu/users/login');
            }
        }
    }

    public function connect(){
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');

        if($this->form_validation->run('connect') == FALSE){
            $this->load->view('users/login');
        }else{
            $password = md5($_POST['password']);
            $email = $_POST['email'];
            $this->load->model('users_model');
            $user = $this->users_model->select_by_email($email);

            if($user->password === $password){
                $_SESSION["id"] = $user->id;
                $_SESSION["type"] = $user->type; 

                if($_SESSION["type"] === "M"){
                    if($this->get_dashboard() === null){
                        header('Location: http://localhost/php_codeigniter/smart_menu/manager/establishment');
                    }else{
                        header('Location: http://localhost/php_codeigniter/smart_menu/manager/dashboard');
                    }
                }
                if($_SESSION["type"] === "C"){
                    
                    $this->load->view('clients/establishments');
                }
            }
        }
    }

    public function get_dashboard(){
        $this->load->model('establishments_model');
        $this->load->model('users_model');
        $this->load->model('menus_model');
        
        $data['user'] = $this->users_model->select_by($_SESSION['id']);
        $data['establishment'] = $this->establishments_model->select_establishment_by_user_id($_SESSION['id']);
        $_SESSION['establishment_id'] = $data['establishment']->id;
        $data['menus'] = $this->menus_model->select_all_by_establishment_id($_SESSION['establishment_id']);

        $this->load->view('users/dashboard', $data);

        return $data['establishment'];
    }
} 