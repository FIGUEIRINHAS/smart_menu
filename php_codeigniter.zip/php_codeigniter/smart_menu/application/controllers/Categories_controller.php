<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Categories_controller extends CI_Controller {

	public function get_all_categories(){
        $this->load->model('categories_model');
        $data['categories'] = $this->categories_model->select_all_by($_SESSION['establishment_id']);
        
        $this->load->view('categories/all_categories', $data);
    }

    public function create_category(){
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');

        if($this->form_validation->run('category_create') == FALSE){
            $this->load->view('categories/form_create_category');
        }else{
            $this->load->model('categories_model');
            $this->categories_model->set_name($_POST['name']);
            $this->categories_model->set_description($_POST['description']);
            $this->categories_model->set_establishment_id($_SESSION['establishment_id']);
            $this->categories_model->insert();

            if($this->categories_model->insert() === true){
                $data['message'] = "Vous pouvez ajouter une nouvelle catégorie";
            }

            $this->load->view('categories/form_create_category', $data);
        }
    }

    public function get_one_category($category_id){
        $this->load->model('categories_model');
        $this->load->model('products_model');
        $data['category'] = $this->categories_model->select_by($category_id);
        $data['product_category'] = $this->products_model->select_products_by_category($category_id);
        $data['products'] = $this->products_model->select_all_by($_SESSION['establishment_id']);

        $this->load->view('categories/category', $data); 
    }

    public function delete_category($category_id){
        $this->load->model('categories_model');
        $this->categories_model->delete($category_id);

        header("Location: http://localhost/php_codeigniter/smart_menu/manager/categories"); 
    }
}
