<?php

class Establishments_controller extends CI_Controller{

    public function display_form(){
        if(isset($_SESSION['type']) && $_SESSION['type'] === "M"){
            $this->load->view('establishments/form_new_establishment');
        }
    }

    public function create_establishment(){
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');

        if($this->form_validation->run('establishement_create') == FALSE){
            $this->load->view('establishments/form_new_establishment');
        }else{
            $this->load->model('establishments_model');

            if(!$this->establishments_model->select_establishment_by_user_id($_SESSION['id'])){
                $this->establishments_model->set_address($_POST['address']);
                $this->establishments_model->set_postal_code($_POST['postal_code']);
                $this->establishments_model->set_city($_POST['city']);
                $this->establishments_model->set_tel($_POST['tel']);
                $this->establishments_model->set_website($_POST['website']);
                $this->establishments_model->set_menu_address($_POST['menu_address']);
                $this->establishments_model->set_user_id($_SESSION['id']);
                $this->establishments_model->insert();
            }
            header('Location:'.base_url('manager/dashboard').'');
        }
    }
}