<?php

class Products_model extends CI_Model{

    public $name;
    public $description;
    public $price;
    public $category_id;
    public $establishment_id;
    public $menu_id;

    public function __construct(){
        $this->load->database();
    }

    public function set_name($name){
        return $this->name = $name;
    }

    public function set_description($description){
        return $this->description = $description;
    }

    public function set_price($price){
        return $this->price = $price;
    }

    public function set_category_id($category_id){
        return $this->category_id = $category_id;
    }

    public function set_establishment_id($establishment_id){
        return $this->establishment_id = $establishment_id;
    }

    public function set_menu_id($menu_id){
        return $this->menu_id = $menu_id;
    }

    public function select_all_by($establishment_id){
        $query = $this->db->where('establishment_id', $establishment_id)
            ->get('product');

        return $query->result_array();
    }

    public function select_by($id){
        $query = $this->db->where('id', $id)
            ->get('product');

        foreach($query->result() as $row){
            return $row;
        }
    }

    public function select_by_menu($id){
        $query = $this->db->where('menu_id', $id)
            ->get('product');

        return $query->result_array();
    }

    public function insert(){
        return $this->db->insert('product', $this);
    }

    public function add_product_category_for($product_id, $category_id){
        $query = $this->db->where('id', $product_id)
        ->update('product', ['category_id' => $category_id]);
    }

    public function add_product_menu_for($product_id, $menu_id){
        $query = $this->db->where('id', $product_id)
        ->update('product', ['menu_id' => $menu_id]);
    }

    public function select_products_by_category($category_id){
        $query = $this->db->where('category_id', $category_id)
        ->get('product');

        return $query->result_array();
    }
}