<?php

class Establishments_model extends CI_Model{

    public $address;
    public $postal_code;
    public $city;
    public $tel;
    public $website;
    public $menu_address;
    public $user_id;

    public function __construct(){
        $this->load->database();
    }

    public function set_address($address){
        return $this->address = $address;
    }

    public function set_postal_code($postal_code){
        return $this->postal_code = $postal_code;
    }

    public function set_city($city){
        return $this->city = $city;
    }

    public function set_tel($tel){
        return $this->tel = $tel;
    }

    public function set_website($website){
        return $this->website = $website;
    }

    public function set_menu_address($menu_address){
        return $this->menu_address = $menu_address;
    }

        public function set_user_id($user_id){
        return $this->user_id = $user_id;
    }

    public function select_establishment_by_user_id($user_id){
        $array = array('user_id' => $user_id, 'is_active' => 'O');
        $this->db->where($array);
        $query = $this->db->get('establishment');

        foreach ($query->result() as $row){
            return $row;
        }
    }

    public function insert(){
        $this->db->insert('establishment', $this);
    }
}