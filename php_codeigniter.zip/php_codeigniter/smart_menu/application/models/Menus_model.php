<?php

class Menus_model extends CI_Model{

    public $name;
    public $description;
    public $speciality;
    public $establishment_id;

    public function __construct(){
        $this->load->database();
    }

    public function set_name($name){
        return $this->name = $name;
    }

    public function set_description($description){
        return $this->description = $description;
    }

    public function set_speciality($speciality){
        return $this->speciality = $speciality;
    }

    public function set_establishment_id($establishment_id){
        return $this->establishment_id = $establishment_id;
    }

    public function select_all_by_speciality($speciality){
        $query = $this->db->where('speciality', $speciality)
            ->get('menu');

        return $query->result_array();
    }

    public function select_all_by_establishment_id($establishment_id){
        $query = $this->db->where('establishment_id', $establishment_id)
            ->get('menu');

        return $query->result_array();
    }

    public function select_by($id){
        $query = $this->db->where('id', $id)
            ->get('menu');

        foreach($query->result() as $row){
            return $row;
        }
    }

    public function insert(){
        $this->db->insert('menu', $this);
        $last_id = $this->db->insert_id();

        return $last_id;
    }

    public function add_price_menu_for($price, $menu_id){
        $query = $this->db->where('id', $menu_id)
        ->update('menu', ['price' => $price]);
    }

    public function delete($menu_id){
        $query = $this->db->where('id', $menu_id)
        ->delete('menu');
    }
}