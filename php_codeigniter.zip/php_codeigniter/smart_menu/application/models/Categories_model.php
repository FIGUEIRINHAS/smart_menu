<?php

class Categories_model extends CI_Model{

    public $name;
    public $description;
    public $establishment_id;

    public function __construct(){
        $this->load->database();
    }

    public function set_name($name){
        return $this->name = $name;
    }

    public function set_description($description){
        return $this->description = $description;
    }

    public function set_establishment_id($establishment_id){
        return $this->establishment_id = $establishment_id;
    }

    public function select_all_by($establishment_id){
        $query = $this->db->where('establishment_id', $establishment_id)
            ->get('category_product');

        return $query->result_array();
    }

    public function select_by($id){
        $query = $this->db->where('id', $id)
            ->get('category_product');

        foreach($query->result_array() as $row){
            return $row;
        }
    }

    public function insert(){
        return $this->db->insert('category_product', $this);
    }

    public function delete($category_id){
        $this->db->where('id', $category_id)->delete('category_product');
    }
}