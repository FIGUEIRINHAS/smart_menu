<?php

class Specialities_model extends CI_Model{

    public $name;
    public $menu_id;

    public function __construct(){
        $this->load->database();
    }

    public function set_name($name){
        return $this->name = $name;
    }

    public function set_menu_id($menu_id){
        return $this->menu_id = $menu_id;
    }

    public function select_all_by($menu_id){
        $query = $this->db->where('menu_id', $menu_id)
            ->get('speciality');

        foreach ($query->result() as $row){
            return $row;
        }
    }

    public function insert(){
        $this->db->insert('speciality', $this);
    }
}