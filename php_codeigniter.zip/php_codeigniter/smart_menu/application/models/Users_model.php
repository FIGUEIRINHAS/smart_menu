<?php

class Users_model extends CI_Model{

    public $email;
    public $password;

    public function __construct(){
        $this->load->database();
    }

    public function set_email($email){
        return $this->email = $email;
    }

    public function set_password($password){
        return $this->password = $password;
    }

    public function set_type($type){
        return $this->type = $type;
    }

    public function select_all(){
        $query = $this->db->get('user');

        foreach ($query->result() as $row){
            return $row;
        }
    }

    public function select_by_email($email){
        $query = $this->db->where('email', $email)
            ->get('user');

        foreach ($query->result() as $row){
            return $row;
        }
    }

    public function select_by($id){
        $query = $this->db->where('id', $id)
            ->get('user');

        foreach ($query->result() as $row){
            return $row;
        }
    }

    public function insert(){
        $this->db->insert('user', $this);
    }
}