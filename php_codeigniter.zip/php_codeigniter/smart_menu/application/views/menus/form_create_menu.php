<?php 
if($this->load->library('form_validation')){
    echo validation_errors();
}
if(isset($message)){ ?>
    <div class ="alert alert-success" role="alert">
        <?= $message; ?>
    </div>
<?php }
$this->load->helper('form'); ?>

<h1 class="title">Création de votre menu</h1>
<p class="description">La spécialité est nécessaire pour que les clients puisse vous retrouvez. 
Vous pouvez ajouter plusieurs produits de la même catégorie si vous le désirez</p>
<div class="form-create-menu">
    <?php echo form_open('http://localhost/php_codeigniter/smart_menu/menu/create');
    ?>
        <div class="form-group">
            <label for="name">Nom</label>
            <input type="text" class="form-control" name="name">
        </div>
        <div class="form-group">
            <label for="description">Description</label>
            <input type="text" class="form-control" name="description">
        </div>
        <div class="form-group">  
            <label for="speciality">Spécialité</label>
            <input type="text" class="form-control" name="speciality">
        </div>
    <div class="container">
        <div class="row">
            <?php foreach($categories as $category){ ?>
                <div class="col">
                    <h4><?= $category['name']; ?></h4>
                    <?php 
                    foreach($products as $product){ 
                        if($product['category_id'] === $category['id']){ ?>
                            <div class="form-group col">  
                                <label for="<?= $product['id'] ?>"><?= $product['name']; ?></label>
                                <input type="checkbox" class="form-control" name="<?= $product['id'] ?>">
                            </div> 
                        <?php } ?>
                    <?php } ?>
                </div>
            <?php } ?>
        </div>
    </div>
    <div class="form-group submit_button">
        <input type="submit" class="form-control btn btn-dark" value="Ajouter">
    </div>
    </form>
</div>

<style>
body{
    background-image: url('https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRRIUM9XpwqjITBvz2kVQ3eh1gPb6lAUL2Hag&usqp=CAU');
}

.form-create-menu {
    background-color: #F0E659;
    margin-right: 25%;
    margin-left: 25%;
    margin-bottom: 25%;
    padding: 3px;
    border: thick double black;
}
.submit_button{
    text-align: center;
    margin-left: 25%;
    margin-right: 25%;
}
.title, .description {
    color: #1F1F1F;
    text-align: center;
    background-color: #EDEDED;
    margin-top: 8px;
    margin-left: 35%;
    margin-right: 35%;
}
</style>