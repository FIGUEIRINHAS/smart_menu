<div class="container">
    <h1 class="title">Menus</h1>
    <div class="row">
        <?php foreach($menus as $menu){ ?>
            <div class="col">
                <p>Nom: <?= $menu['name']; ?></p>
                <p>Description: <?= $menu['description']; ?></p>
                <p>Spécialité: <?= $menu['speciality']; ?></p>
                <p>Prix: <?= $menu['price']; ?></p>
                <a href="http://localhost/php_codeigniter/smart_menu/menu/delete/<?= $menu['id'] ?>"><button class="btn btn-danger">Supprimer</button></a>
            </div>
        <?php } ?>
    </div>
</div>
<div class="add_menu">
    <a href="http://localhost/php_codeigniter/smart_menu/menu/form">
        <button class="btn btn-info">Créer un menu</button>
    </a>
</div>

<style>
body{
    background-image: url('https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRRIUM9XpwqjITBvz2kVQ3eh1gPb6lAUL2Hag&usqp=CAU');
}
.row {
    padding: 5px;
    background-color: #EDEDED;
}
.col {
    background-color: #F0E659;
}
p, h4 {
    color: #1F1F1F;
}
.title {
    color: #1F1F1F;
    text-align: center;
    background-color: #EDEDED;
    margin-top: 8px;
    margin-left: 35%;
    margin-right: 35%;
}
.add_menu{
    text-align: center;
}
</style>