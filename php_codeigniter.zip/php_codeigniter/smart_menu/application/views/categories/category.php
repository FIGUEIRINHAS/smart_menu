<div class="container">
    <h1 class="title">Catégorie n°<?= $category['id']; ?></h1>
    <div class="row">
        <div class="col">
            <p>Nom: <?= $category['name']; ?></p>
            <p>Description: <?= $category['description']; ?></p>
        </div>
    </div>
    <h1 class="title">Produits de la catégorie <?= $category['name']; ?></h1>
    <div class="row">
        <?php foreach($product_category as $product){ ?>
            <div class="col">
                <p>Nom: <?= $product['name']; ?></p>
                <p>Description: <?= $product['description']; ?></p>
                <p>Prix: <?= $product['price']; ?></p>
            </div>
        <?php } ?>
    </div>
    <h1 class="title">Tous vos produits</h1>
    <p class="p-description">Vous pouvez ajouter directement les différents produits juste en cliquant sur les cases. 
    Plusieurs produits peuvent être ajoutés en même temps</p>
    <div class="form-add-product-category">
        <form action="http://localhost/php_codeigniter/smart_menu/product/category/<?= $category['id']; ?>" method="post">
            <div class="row">
                <?php foreach($products as $product){ ?>
                    <div class="form-group col-md-2">
                        <label for="<?= $product['id'] ?>"><?= $product['name']; ?></label>
                        <input type="checkbox" class="form-control" name="<?= $product['id'] ?>">
                    </div>
                <?php } ?>
                <div class="form-group col-md-2">
                    <input type="submit" class="btn btn-dark" value="Ajouter">
                </div>
            </div>
        </form>
    </div>
</div>

<style>
body{
    background-image: url('https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRRIUM9XpwqjITBvz2kVQ3eh1gPb6lAUL2Hag&usqp=CAU');
}
.row {
    padding: 5px;
    background-color: #EDEDED;
}
.col {
    background-color: #F0E659;
}
p, h4 {
    color: #1F1F1F;
}
.title {
    color: #1F1F1F;
    text-align: center;
    background-color: #EDEDED;
    margin-top: 8px;
    margin-left: 30%;
    margin-right: 30%;
}
.p-description {
    color: #1F1F1F;
    text-align: center;
    background-color: #EDEDED;
    margin-top: 8px;
    margin-left: 30%;
    margin-right: 30%;
}
.form-add-product-category {
    margin-right: 25%;
    margin-left: 25%;
    margin-bottom: 25%;
}
</style>