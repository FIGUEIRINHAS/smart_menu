<div class="container">
    <h1 class="title">Catégories</h1>
    <div class="row">
        <?php foreach($categories as $category){ ?>
            <div class="col">
                <p>Nom: <?= $category['name']; ?></p>
                <p>Description: <?= $category['description']; ?></p>
                <a href="http://localhost/php_codeigniter/smart_menu/manager/category/<?= $category['id'] ?>">
                <button class="btn btn-dark">Détails</button></a>
                <a href="http://localhost/php_codeigniter/smart_menu/category/delete/<?= $category['id'] ?>">
                <button class="btn btn-danger">Supprimer</button></a>
            </div>
        <?php } ?> 
    </div>
</div>  
<div class="add_category">
    <a href="http://localhost/php_codeigniter/smart_menu/category/create">
        <button class="btn btn-info">Ajouter une catégorie</button>
    </a>
</div> 

<style>
body{
    background-image: url('https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRRIUM9XpwqjITBvz2kVQ3eh1gPb6lAUL2Hag&usqp=CAU');
}
.row {
    padding: 5px;
    background-color: #EDEDED;
}
.col {
    background-color: #F0E659;
}
p, h4 {
    color: #1F1F1F;
}
.title {
    color: #1F1F1F;
    text-align: center;
    background-color: #EDEDED;
    margin-top: 8px;
    margin-left: 35%;
    margin-right: 35%;
}
.add_category{
    text-align: center;
}
</style>