<?php

if($this->load->library('form_validation')){
    echo validation_errors();
}
if(isset($message)){ ?>
    <div class ="alert alert-success" role="alert">
        <?= $message; ?>
    </div>
<?php }
$this->load->helper('form'); ?>

<h1 class="title">Création d'une catégorie</h1>
<div class="form-category"> 
<?php echo form_open('http://localhost/php_codeigniter/smart_menu/category/create'); ?>
    <div class="form-group">
        <label for="name">Name</label>
        <input type="text" class="form-control" name="name">
    </div>
    <div class="form-group">
        <label for="description">Description</label>
        <input type="textarea" class="form-control" name="description">
    </div>
    <div class="form-group submit_button">
        <input type="submit" class="form-control btn btn-dark" value="Ajouter">
    </div>
</div>

<style>
body{
    background-image: url('https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRRIUM9XpwqjITBvz2kVQ3eh1gPb6lAUL2Hag&usqp=CAU');
}

.form-category {
    background-color: #F0E659;
    margin-right: 25%;
    margin-left: 25%;
    margin-bottom: 25%;
    padding: 3px;
    border: thick double black;
}
.submit_button{
    text-align: center;
    margin-left: 25%;
    margin-right: 25%;
}
.title {
    color: #1F1F1F;
    text-align: center;
    background-color: #EDEDED;
    margin-top: 8px;
    margin-left: 35%;
    margin-right: 35%;
}
</style>