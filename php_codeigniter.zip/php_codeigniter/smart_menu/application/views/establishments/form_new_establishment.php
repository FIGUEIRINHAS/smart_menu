<?php

if($this->load->library('form_validation')){
    echo validation_errors();
}
$this->load->helper('form');

echo form_open('http://localhost/php_codeigniter/smart_menu/establishment/create');
echo form_label('Adresse', 'address');
echo form_input('address');
echo form_label('Code postal', 'postal_code');
echo form_input('postal_code');
echo form_label('Ville', 'city');
echo form_input('city');
echo form_label('Tél', 'tel');
echo form_input('tel');
echo form_label('Site-web', 'website');
echo form_input('website');
echo form_label('Adresse restaurant', 'menu_address');
echo form_input('menu_address');
echo form_submit('', 'Créer');