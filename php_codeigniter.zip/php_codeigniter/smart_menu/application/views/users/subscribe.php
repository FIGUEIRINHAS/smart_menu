<?php $this->load->helper('form'); ?>

<div class="form-subscribe">
    <?php echo form_open('http://localhost/php_codeigniter/smart_menu/users/create'); ?>
        <?php if($this->load->library('form_validation')){
            echo validation_errors();
        } ?>
        <h4>Connexion</h4>
        <div class="form-group col-md-5">
            <label for="email">Email</label>
            <div class="input-group mb-2">
                <div class="input-group-prepend">
                    <div class="input-group-text">@</div>
                </div>
                <input type="text" class="form-control" name="email" placeholder="Enter email">
            </div>
        </div>
        <div class="form-group col-md-5">
            <label for="password">Mot de passe</label>
            <input type="password" class="form-control" name="password" placeholder="password">
        </div>
        <div class="form-group col-md-5">
            <label for="password_verif">Retapez votre mot de passe</label>
            <input type="password" class="form-control" name="password_verif" placeholder="password">
        </div>
        <?php $options = [
            'M'  => 'Manager',
            'C'    => 'Client'
        ];
        
        echo form_dropdown('type', $options, 'C');
        ?>
        <div class="form-group submit-button">
            <input type="submit" class="form-control btn btn-dark" value="S'inscrire">
        </div>
    </form>
</div>

<style>
body{
    background-image: url('https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRRIUM9XpwqjITBvz2kVQ3eh1gPb6lAUL2Hag&usqp=CAU');
}

.form-subscribe {
    background-color: #F0E659;
    margin-right: 25%;
    margin-left: 25%;
    margin-bottom: 25%;
    margin-top: 8%;
    padding: 3px;
    border: thick double black;
}

.submit_button{
    text-align: center;
}
</style>