<div class="container">
    <h1 class="title">Profil</h1>
    <div class="row">
        <div class="col">
            <h4>Utilisateur</h4><br>
            <p>Email: <?= $user->email; ?></p>
            <p>Type: <?= $user->type; ?></p>
        </div>
        <div class="col">
            <h4>Établissement</h4><br>
            <p>Adresse: <?= $establishment->address; ?></p>
            <p>Code postal: <?= $establishment->postal_code; ?></p>
            <p>Ville: <?= $establishment->city; ?></p>
            <p>Tél: <?= $establishment->tel; ?></p>
        </div>
    </div>
    <h1 class="title">Menus</h1>
    <div class="row">
        <?php foreach($menus as $menu){ ?>
            <div class="col-4">
                <h4><?= $menu['name']; ?></h4>
                <p>Spécialité: <strong><?= $menu['speciality']; ?></strong></p>
                <p>Prix: <strong><?= $menu['price']; ?></strong></p>
            </div>
        <?php } ?>
    </div>
</div>

<style>
body{
    background-image: url('https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRRIUM9XpwqjITBvz2kVQ3eh1gPb6lAUL2Hag&usqp=CAU');
}
.row {
    padding: 5px;
    background-color: #EDEDED;
}
.col {
    background-color: #F0E659;
}
p, h4 {
    color: #1F1F1F;
}
.title {
    color: #1F1F1F;
    text-align: center;
    background-color: #EDEDED;
    margin-top: 8px;
    margin-left: 35%;
    margin-right: 35%;
}
</style>