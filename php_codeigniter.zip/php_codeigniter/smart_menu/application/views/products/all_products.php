<div class="container">
    <h1 class="title">Produits</h1>
    <div class="row">
        <?php foreach($products as $product){ ?>
            <div class="col">
                <p>Nom: <?= $product['name'] ?></p>
                <p>Description: <?= $product['description'] ?></p>
                <p>Prix: <?= $product['price'] ?>$</p>
            </div>
        <?php } ?>
    </div>
</div>  

<div class="add_product">
    <a href="http://localhost/php_codeigniter/smart_menu/product/create"><button class="btn btn-info">Ajouter un produit</button></a>
</div>  

<style>
body{
    background-image: url('https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRRIUM9XpwqjITBvz2kVQ3eh1gPb6lAUL2Hag&usqp=CAU');
}
.row {
    padding: 5px;
    background-color: #EDEDED;
}
.col {
    background-color: #F0E659;
}
p, h4 {
    color: #1F1F1F;
}
.title {
    color: #1F1F1F;
    text-align: center;
    background-color: #EDEDED;
    margin-top: 8px;
    margin-left: 35%;
    margin-right: 35%;
}
.add_product{
    text-align: center;
}
</style>